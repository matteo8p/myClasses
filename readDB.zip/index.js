"use strict";
const MongoClient = require('mongodb').MongoClient;
const MONGODB_URI = "mongodb+srv://matt8p:123abc@cluster0-en6ic.mongodb.net/test"; // or Atlas connection string

let cachedDb = null;


function connectToDatabase (uri) {

  console.log('=> connect to database');



  if (cachedDb) {

    console.log('=> using cached database instance');

    return Promise.resolve(cachedDb);

  }



  return MongoClient.connect(uri)

    .then(db => {

      cachedDb = db;

      return cachedDb;

    });

}


function queryDatabase (db) {
  console.log('=> query database');

  var dbo = db.db("criminalDB");
   var dataArray = dbo.collection('person').find({}).toArray();
  // console.log(dataArray);
  // var jsonFile = JSON.stringify(dataArray);

return dataArray;
  // return dbo.collection('person').find({}).toArray()
  //   .then(() => { return { statusCode: 200, body: 'okk' }; })
  //   .catch(err => {
  //     console.log('=> an error occurred: ', err);
  //     return { statusCode: 500, body: 'error' };
  //   });
    

}

module.exports.handler = (event, context, callback) => {

  context.callbackWaitsForEmptyEventLoop = false;


  console.log('event: ', event);

  connectToDatabase(MONGODB_URI)
    .then(db => queryDatabase(db))
    .then(result => {
      console.log('=> returning result: ', result);
       callback(null, { statusCode: 200, body : JSON.stringify((result))});
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
};
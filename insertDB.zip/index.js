"use strict";
const MongoClient = require('mongodb').MongoClient;
const MONGODB_URI = "mongodb+srv://matt8p:123abc@cluster0-en6ic.mongodb.net/test";


let cachedDb = null;

function connectToDatabase (uri) {
  console.log('=> connect to database');

  if (cachedDb) {
    console.log('=> using cached database instance');
    return Promise.resolve(cachedDb);
  }

  return MongoClient.connect(uri)
    .then(db => {
      cachedDb = db;
      return cachedDb;
    });
}

function queryDatabase (db,event) {
  console.log('=> query database');
    //  let firstName = event.first_name;
    //  let lastName = event.last_name;
    //  let sex = event.sex;
    //  let reason = event.reason;
    
  var post_data = event.body;
  console.log('post_da:',post_data);
  var data = JSON.parse(post_data);
    
  var dbo = db.db("criminalDB");
  return dbo.collection('person').insertOne(data)
    .then(() => { return { statusCode: 200, body: 'success' }; })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      return { statusCode: 500, body: 'error' };
    });
}

module.exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  console.log('event: ', event);

  connectToDatabase(MONGODB_URI)
    .then(db => queryDatabase(db,event))
    .then(result => {
      console.log('=> returning result: ', result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
};